package com.thinking.machines.dao;

import com.thinking.machines.dto.SignUpDto;

public interface RegistrationDao {

	public String getSignUp(SignUpDto signUpObj);
}
