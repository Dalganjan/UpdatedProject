package com.thinking.machines.dao;

import org.springframework.stereotype.Repository;

import com.thinking.machines.dto.SignUpDto;

@Repository
public class RegistrationDaoImpl implements RegistrationDao {

	@Override
	public String getSignUp(SignUpDto signUpObj) {
		// TODO Auto-generated method stub
		
		System.out.println("Obj name"+ signUpObj.getName());
		return null;
	}

}
