package com.thinking.machines.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinking.machines.dao.RegistrationDao;
import com.thinking.machines.dto.SignUpDto;


@Service
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	private RegistrationDao registrationObj;
	
	@Override
	public String getSignUp(SignUpDto signUpObj) {
		// TODO Auto-generated method stub
		registrationObj.getSignUp(signUpObj);
		return null;
	}

}
