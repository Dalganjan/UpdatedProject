package com.thinking.machines.services;

import com.thinking.machines.dto.SignUpDto;

public interface RegistrationService {

	public String getSignUp(SignUpDto signUpObj);
	
	
}
