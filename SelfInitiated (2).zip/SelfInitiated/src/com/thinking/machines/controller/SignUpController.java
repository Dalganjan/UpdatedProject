package com.thinking.machines.controller;

import java.sql.SQLException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.thinking.machines.dto.SignUpDto;
import com.thinking.machines.services.RegistrationService;


@Controller("SignUp")
public class SignUpController {

   @Autowired
   private RegistrationService regisObj;
	
	@RequestMapping(value="/app/userSignup",method=RequestMethod.POST)
	public @ResponseBody String getSlotsAvailable(@RequestBody String slot) throws SQLException
	{
		System.out.println(slot);
		Gson n=new Gson();
		SignUpDto signUpobj;
		signUpobj=n.fromJson(slot, SignUpDto.class);
		regisObj.getSignUp(signUpobj);
		return null;
	}
	
}
